/*
Aufgabe: Abschlussarbeit
Name: Julia Kaiser
Matrikel: 256580
Datum: 14.02.2018

Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.

*/
var Abschluss;
(function (Abschluss) {
    class DrinkArray {
        constructor(_x, _y, _color) {
            this.x = _x;
            this.y = _y;
            this.color = _color;
        }
        update() {
            this.draw();
            this.move();
        }
        draw() {
            //hh
        }
        move() {
            //hh
        }
    }
    Abschluss.DrinkArray = DrinkArray;
})(Abschluss || (Abschluss = {}));
//# sourceMappingURL=Superclass.js.map